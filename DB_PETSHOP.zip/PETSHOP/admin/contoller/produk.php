<?php
$con->auth();
$conn=$con->koneksi();
switch (@$_GET['page']){
    case 'add':
        $produk="select * from produk";
        $produk=$conn->query($produk);
        $sql="select * from produk";
        $produk=$conn->query($sql);
        $content="views/produk/tambah.php";
        include_once 'views/template.php';
    break;
    case 'save':
        if($_SERVER['REQUEST_METHOD']=="POST"){
            //validasi
            if(empty($_POST['nama'])){
                $err['nama']="Nama produk Wajib";
            }
            if(empty($_POST['jenis'])){
                $err['jenis']="Jenis Produk Wajib Terisi";
            }
            if(!is_numeric($_POST['harga'])){
                $err['harga']="Harga Wajib diisi";
            }
            if(!isset($err)){
                $id_pegawai=$_SESSION['login']['id'];
                if(!empty($_POST['id_produk'])){
                    //update
                    $sql="UPDATE produk SET nama='$_POST[nama]', jenis='$_POST[jenis]', harga='$_POST[harga]' WHERE id_produk='$_POST[id_produk]'";
                }else{
                    //save
                    $sql = "INSERT INTO produk (nama, jenis, harga) 
                    VALUES ('$_POST[nama]','$_POST[jenis]','$_POST[harga]')";
                }
                    if ($conn->query($sql) === TRUE) {
                        header('Location: '.$con->site_url().'/admin/index.php?mod=produk');
                    } else {
                        $err['msg']= "Error: " . $sql . "<br>" . $conn->error;
                    }
            }
        }else{
            $err['msg']="tidak diijinkan";
        }
        if(isset($err)){
            $content="views/produk/tambah.php";
            include_once 'views/template.php';
        }
    break;
    case 'edit':
        $produk="select * from produk where id_produk='$_GET[id]'";
        $produk=$conn->query($produk);
        $_POST=$produk->fetch_assoc();
        $_POST['id_produk']=$_POST['id_produk'];
        //var_dump($dokter);
        $pdk="select*from produk";
        $prk=$conn->query($pdk);
        $content="views/produk/tambah.php";
        include_once 'views/template.php';
    break;
    case 'delete';
        $produk="DELETE FROM produk WHERE id_produk='$_GET[id]'";
        $produk=$conn->query($produk);
        header('Location: '.$con->site_url().'/admin/index.php?mod=produk');
    break;
    default:
        $sql="select*from produk";
        $produk=$conn->query($sql);
        $conn->close();
        $content="views/produk/tampil.php";
        include_once 'views/template.php';
}
?>